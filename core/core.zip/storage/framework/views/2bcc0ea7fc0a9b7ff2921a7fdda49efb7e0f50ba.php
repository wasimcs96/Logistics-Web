<?php $__env->startSection('content'); ?>
<form  class="" action="<?php echo e(route('admin.truck.update',['id'=>$truck->id])); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <div class="row" style="justify-content: center;">
  <div class="mb-3 col-lg-6">
    <div class="form-group">
      <label for="">Truck Number **</label>
      <input type="number" class="form-control" name="truck_number" placeholder="Enter truck number" value="<?php echo e($truck->truck_number); ?>">
      <p id="errusername" class="mb-0 text-danger em"></p>
    </div>
  </div>
</div>

  <div class="row" style="justify-content: center;">
  <div class="mb-3 col-lg-6">
    <div class="form-group">
      <label for="">Company Name **</label>
      <input type="text" class="form-control" name="company_name" placeholder="Enter company name" value="<?php echo e($truck->company_name); ?>">
      <p id="erremail" class="mb-0 text-danger em"></p>
    </div>
  </div>
</div>

  <div class="row" style="justify-content: center;">
  <div class="mb-3 col-lg-6">
    <div class="form-group">
      <label for="">Load Weight **</label>
      <input type="text" class="form-control" name="load_weight" placeholder="Enter load weight" value="<?php echo e($truck->load_weight); ?>">
      <p id="erremail" class="mb-0 text-danger em"></p>
    </div>
  </div>
</div>

  <div class="row" style="justify-content: center;">
    <button  type="submit" class="btn btn-primary">Update</button>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\logistics\core\resources\views/admin/trucks/edit.blade.php ENDPATH**/ ?>